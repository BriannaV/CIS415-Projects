
int file_fork(char* file_name);

void alarm_handler(int signum); 

void print_proc(pid_t pid);
