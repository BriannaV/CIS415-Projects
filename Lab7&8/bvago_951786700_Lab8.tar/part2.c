#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include "account.h"

/* Im sorry this is late, i redid the entire file today because while making
 * the tar file i accidentally rewrote this one.*/

void transfer(account* array, char* a_src, char* password, char* a_dest, double val) {
	int src;
	int dest;
	
	if(a_src == a_dest) {
		printf("Cant transfer to and from same account.\n");
		return;
	}

	for(int i=0;i<sizeof(array);i++) {
		if(strcmp(array[i].account_number, a_src)==0) {
			src = i;
		}
		if(strcmp(array[i].account_number, a_dest)==0) {
			dest = i;
		}
	}
	array[src].balance -= val;
	array[dest].balance = array[dest].balance + val;
	array[src].transaction_tracter += val;
}

void check(account* array, char* account, char* password) {

	int src;
	for(int i=0;i<sizeof(array);i++) {
		if(strcmp(array[i].account_number, account)==0) {
			src = i;
			break;
		}
	}

}

void deposit(account* array, char* account, char* password, double val) {

	int src;
	for(int i=0; i<sizeof(array);i++) {
		if(strcmp(array[i].account_number, account)==0) {
			src = i;
			break;
		}
	}
	array[src].balance += val;
	array[src].transaction_tracter += val;
}

void withdraw(account* array, char* account, char* password, double val) {

	int src;
	for(int i=0; i<sizeof(array);i++) {
		if(strcmp(array[i].account_number, account)==0) {
			src = i;
			break;
		}
	}
	array[src].balance -= val;
	array[src].transaction_tracter += val;
}

void reward(account* array) {
	double r;

	for(int i=0;i<sizeof(array);i++) {
		r = (array[i].transaction_tracter) * (array[i].reward_rate);
		array[i].balance += r;
	}
}

void print_array(account* array, int num) {

	for(int i=0;i<num; i++) {
		printf("%d balance: %0.2f\n", i, array[i].balance);
	}
}

int pass_check(account* array, char* account, char* password) {
	for(int i=0;i<sizeof(array);i++) {
		if(strcmp(array[i].account_number, account) ==0) {
			if(strcmp(array[i].password, password) ==0) {
				return 1;
			}
			else {
				return 0;
			}
		}
	}
}

int main(int argc, char* argv[]) {
	FILE* f;
	char* buf;
	size_t bufsiz = 0;

	const char delim1[3] = "\n";
	const char delim2[3] = " ";

	char* command;

	f = fopen(argv[1], "r");

	if(f == NULL) {
		printf("ERROR: couldnt open file\n");
		return EXIT_FAILURE;
	}

	getline(&buf, &bufsiz, f);
	int num = atoi(buf);

	account* array;
	array = (account*)malloc(sizeof(account)*(num+1));

	double b_val;
	double d_val;

	for(int i=0;i<num;i++) {
		account temp;
		
		getline(&buf, &bufsiz, f);

		fscanf(f, "%s", temp.account_number);
		
		fscanf(f, "%s", temp.password);

		fscanf(f, "%le", &b_val);
		temp.balance = b_val;

		fscanf(f, "%le", &d_val);
		temp.reward_rate = d_val;

		getline(&buf, &bufsiz, f);

		array[i] = temp;

	}
	
	//print_array(array, num);
	//printf("------------------------------\n");
	getline(&buf, &bufsiz, f);

	char* a_src;
	char* d_src;
	char* password;
	double money;
	char* ammount;
	char* eptr;
	int help;

	while(fgets(buf, bufsiz, f) != NULL) {
		buf = strtok(buf, delim1);
		command = strtok(buf, delim2);

		if(strcmp(command, "T") == 0) {
			a_src = strtok(NULL, delim2);
			password = strtok(NULL, delim2);
			d_src = strtok(NULL, delim2);
			ammount = strtok(NULL, delim2);

			money = strtod(ammount, &eptr);
			
			help = pass_check(array, a_src, password);
		
			if(help == 1) {	
				transfer(array, a_src, password, d_src, money);
				//print_array(array, num);
				//printf("--------------\n");
			}
		}
		if(strcmp(command, "C")==0) {
			a_src = strtok(NULL, delim2);
			password = strtok(NULL, delim2);

			help = pass_check(array, a_src, password);
			if(help == 1) {
				check(array, a_src, password);
			}
		}
		if(strcmp(command, "D")==0) {
			a_src = strtok(NULL, delim2);
			password = strtok(NULL, delim2);
			ammount = strtok(NULL, delim2);

			money = strtod(ammount, &eptr);

			help = pass_check(array, a_src, password);
			if(help == 1) {
				deposit(array, a_src, password, money);
				//print_array(array, num);
				//printf("---------------\n");
			}
		}
		if(strcmp(command, "W")==0) {
			a_src = strtok(NULL, delim2);
			password = strtok(NULL, delim2);
			ammount = strtok(NULL, delim2);

			money = strtod(ammount, &eptr);
			
			help = pass_check(array, a_src, password);
			if(help ==1) {
				withdraw(array, a_src, password, money);
				//print_array(array, num);
				//printf("------------------\n");
			}
		}
	}
	reward(array);
	print_array(array, num);
	return EXIT_SUCCESS;
}





