#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include "account.h"

/* Im sorry this is late, i redid the entire file today because while making
 * the tar file i accidentally rewrote this one.*/

void transfer(account* array, char* a_src, char* password, char* a_dest, double val) {
	int src;
	int dest;
	
	if(a_src == a_dest) {
		printf("Cant transfer to and from same account.\n");
		return;
	}

	for(int i=0;i<sizeof(array);i++) {
		if(array[i].account_number == a_src) {
			src = i;
		}
		if(array[i].account_number == a_dest) {
			dest = i;
		}
	}
	if(array[src].password == password) {
		array[src].balance -= val;
		array[dest].balance += val;
		array[src].transaction_tracter += 1;
	}
	else {
		printf("Error: wrong password.\n");
	}
}

void check(account* array, char* account, char* password) {

	int src;
	for(int i=0;i<sizeof(array);i++) {
		if(array[i].account_number == account) {
			src = i;
			break;
		}
	}
	if(array[src].password == password) {
		array[src].transaction_tracter += 1;
	}
	else {
		printf("Error: wrong password\n");
	}

}

void deposit(account* array, char* account, char* password, double val) {

	int src;
	for(int i=0; i<sizeof(array);i++) {
		if(array[i].account_number == account) {
			src = i;
			break;
		}
	}
	if (array[src].password == password) {
		array[src].balance += val;
		array[src].transaction_tracter += 1;
	}
	else {
		printf("Error: wrong password\n");
	}
}

void withdraw(account* array, char* account, char* password, double val) {

	int src;
	for(int i=0; i<sizeof(array);i++) {
		if(array[i].account_number == account) {
			src = i;
			break;
		}
	}
	if(array[src].password == password) {
		array[src].balance -= val;
		array[src].transaction_tracter += 1;
	}
	else {
		printf("Error: wrong password\n");
	}
}

void reward(account* array) {
	double r;

	for(int i=0;i<sizeof(array);i++) {
		r = (array[i].transaction_tracter) * (array[i].reward_rate);
		array[i].balance += r;
	}
}

void print_array(account* array) {

	for(int i=0;i<sizeof(array); i++) {
		printf("%d balance: %lf\n", i, array[i].balance);
	}
}

int main(int argc, char* argv[]) {
	FILE* f;
	char* buf;
	size_t bufsiz = sizeof(char)*100;

	const char delim1[3] = "\n";
	const char delim2[3] = " ";

	char* command;

	f = fopen(argv[1], "r");

	if(f == NULL) {
		printf("ERROR: couldnt open file\n");
		return EXIT_FAILURE;
	}

	getline(&buf, &bufsiz, f);
	int num = atoi(buf);

	account* array;
	array = (account*)malloc(sizeof(account)*(num+1));

	double b_val;
	double d_val;

	for(int i=0;i<=num;i++) {
		account temp;
		array[i] = temp;

		getline(&buf, &bufsiz, f);

		fscanf(f, "%s", temp.account_number);
		
		fscanf(f, "%s", temp.password);

		fscanf(f, "%le", &b_val);
		temp.balance = b_val;

		fscanf(f, "%le", &d_val);
		temp.reward_rate = d_val;
	}
	
	getline(&buf, &bufsiz, f);

	char* a_src;
	char* d_src;
	char* password;
	double money;
	char* ammount;
	char* eptr;

	while(!feof(f)) {
		getline(&buf, &bufsiz, f);
		buf = strtok(buf, delim1);
		command = strtok(buf, delim2);

		if(command == "T") {
			a_src = strtok(NULL, delim2);
			password = strtok(NULL, delim2);
			d_src = strtok(NULL, delim2);
			ammount = strtok(NULL, delim2);

			money = strtod(ammount, &eptr);
			
			transfer(array, a_src, password, d_src, money);
		}
		if(command == "C") {
			a_src = strtok(NULL, delim2);
			password = strtok(NULL, delim2);

			check(array, a_src, password);
		}
		if(command == "D") {
			a_src = strtok(NULL, delim2);
			password = strtok(NULL, delim2);
			ammount = strtok(NULL, delim2);

			money = strtod(ammount, &eptr);

			deposit(array, a_src, password, money);
		}
		if(command == "W") {
			a_src = strtok(NULL, delim2);
			password = strtok(NULL, delim2);
			ammount = strtok(NULL, delim2);

			money = strtod(ammount, &eptr);

			withdraw(array, a_src, password, money);
		}
	}
	reward(array);
	print_array(array);
	return EXIT_SUCCESS;
}





